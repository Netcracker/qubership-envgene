Synthetic fixture for OSS unit tests.
